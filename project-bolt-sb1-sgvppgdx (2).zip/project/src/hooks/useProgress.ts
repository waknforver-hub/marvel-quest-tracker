import { useState, useEffect, useCallback } from 'react';
import type { ProgressState } from '../types';

const STORAGE_KEY = 'marvel-quest-progress';

const defaultState: ProgressState = {
  watched: {},
  inProgress: [],
  favorites: [],
  recentlyWatched: [],
  filters: {
    type: 'ALL',
    universe: 'ALL',
    phase: 'ALL',
    saga: 'ALL',
    watched: 'ALL',
  },
  watchOrder: 'release',
  profile: {
    nickname: 'Marvel Fan',
    avatar: 'hero',
    favoriteCharacter: '',
    favoriteMovie: '',
  },
  hasSeenIntro: false,
  doomsdayPlan: 'full',
};

function loadState(): ProgressState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...defaultState,
        ...parsed,
        inProgress: parsed.inProgress || [],
        filters: {
          ...defaultState.filters,
          ...parsed.filters,
          universe: parsed.filters?.universe || 'ALL',
        },
        profile: { ...defaultState.profile, ...parsed.profile },
      };
    }
  } catch {
    // ignore
  }
  return defaultState;
}

export function useProgress() {
  const [state, setState] = useState<ProgressState>(loadState);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // ignore
    }
  }, [state]);

  const toggleWatched = useCallback((id: string) => {
    setState((prev) => {
      const isWatched = !!prev.watched[id];
      const watched = { ...prev.watched, [id]: !isWatched };
      let recentlyWatched = prev.recentlyWatched;
      let inProgress = prev.inProgress;
      if (!isWatched) {
        recentlyWatched = [id, ...prev.recentlyWatched.filter((x) => x !== id)].slice(0, 20);
        inProgress = prev.inProgress.filter((x) => x !== id);
      }
      return { ...prev, watched, recentlyWatched, inProgress };
    });
  }, []);

  const toggleInProgress = useCallback((id: string) => {
    setState((prev) => {
      const isInProgress = prev.inProgress.includes(id);
      const inProgress = isInProgress
        ? prev.inProgress.filter((x) => x !== id)
        : [...prev.inProgress, id];
      return { ...prev, inProgress };
    });
  }, []);

  const toggleFavorite = useCallback((id: string) => {
    setState((prev) => {
      const isFav = prev.favorites.includes(id);
      const favorites = isFav
        ? prev.favorites.filter((x) => x !== id)
        : [...prev.favorites, id];
      return { ...prev, favorites };
    });
  }, []);

  const setFilters = useCallback((filters: Partial<ProgressState['filters']>) => {
    setState((prev) => ({ ...prev, filters: { ...prev.filters, ...filters } }));
  }, []);

  const resetFilters = useCallback(() => {
    setState((prev) => ({ ...prev, filters: { ...defaultState.filters } }));
  }, []);

  const setWatchOrder = useCallback((order: 'release' | 'chronological') => {
    setState((prev) => ({ ...prev, watchOrder: order }));
  }, []);

  const setProfile = useCallback((profile: Partial<ProgressState['profile']>) => {
    setState((prev) => ({ ...prev, profile: { ...prev.profile, ...profile } }));
  }, []);

  const setHasSeenIntro = useCallback((seen: boolean) => {
    setState((prev) => ({ ...prev, hasSeenIntro: seen }));
  }, []);

  const setDoomsdayPlan = useCallback((plan: 'quick' | 'full') => {
    setState((prev) => ({ ...prev, doomsdayPlan: plan }));
  }, []);

  const resetProgress = useCallback(() => {
    setState({ ...defaultState, hasSeenIntro: true });
  }, []);

  return {
    state,
    toggleWatched,
    toggleInProgress,
    toggleFavorite,
    setFilters,
    resetFilters,
    setWatchOrder,
    setProfile,
    setHasSeenIntro,
    setDoomsdayPlan,
    resetProgress,
  };
}

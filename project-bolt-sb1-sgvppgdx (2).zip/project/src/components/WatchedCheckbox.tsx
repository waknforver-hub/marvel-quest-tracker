import { Check } from 'lucide-react';
import { useState } from 'react';

interface WatchedCheckboxProps {
  watched: boolean;
  onToggle: () => void;
  doomsdayTheme?: boolean;
}

export function WatchedCheckbox({ watched, onToggle, doomsdayTheme = false }: WatchedCheckboxProps) {
  const [animating, setAnimating] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggle();
    if (!watched) {
      setAnimating(true);
      setTimeout(() => setAnimating(false), 600);
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`relative flex items-center justify-center rounded-lg border-2 transition-all duration-300 active:scale-90 ${
        watched
          ? doomsdayTheme
            ? 'bg-red-900/40 border-red-600'
            : 'bg-red-600/30 border-red-500'
          : doomsdayTheme
            ? 'bg-transparent border-white/30 hover:border-white/50'
            : 'bg-transparent border-white/25 hover:border-white/45'
      } ${animating ? 'scale-125' : ''}`}
      style={{ width: 32, height: 32, transition: 'all 0.3s ease' }}
      aria-label={watched ? 'Mark as unwatched' : 'Mark as watched'}
    >
      {watched && (
        <Check
          className={doomsdayTheme ? 'text-red-400' : 'text-red-400'}
          size={20}
          strokeWidth={3}
          style={{ animation: 'fadeIn 0.3s ease' }}
        />
      )}
    </button>
  );
}

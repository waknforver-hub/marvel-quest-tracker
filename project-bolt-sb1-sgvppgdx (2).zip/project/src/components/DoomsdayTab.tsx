import { useMemo, useState, useEffect } from 'react';
import {
  Zap,
  Shield,
  Target,
  Sparkles,
  ChevronDown,
  Check,
  Clock,
  Play,
  X,
  Info,
} from 'lucide-react';
import type { ProgressState, McuTitle, DoomsdayCategory } from '../types';
import { MCU_CATALOGUE } from '../data/catalogue';
import { DOOMSDAY_PLAN, DOOMSDAY_RELEASE_DATE } from '../data/doomsdayPlan';
import {
  countWatched,
  calcPercentage,
  getWatchedMinutes,
  formatRuntime,
  formatHours,
  getDoomsdayEntry,
  getCountdown,
} from '../utils/calculations';
import { ProgressRing } from './ProgressRing';
import { ProgressBar } from './ProgressBar';
import { WatchedCheckbox } from './WatchedCheckbox';

interface DoomsdayTabProps {
  state: ProgressState;
  onToggleWatched: (id: string) => void;
  onSetDoomsdayPlan: (plan: 'quick' | 'full') => void;
}

const CATEGORY_CONFIG: Record<
  DoomsdayCategory,
  { label: string; icon: typeof Shield; color: string; bgColor: string }
> = {
  core: { label: 'Core', icon: Shield, color: '#dc2626', bgColor: 'bg-red-900/20' },
  important: { label: 'Important', icon: Target, color: '#f59e0b', bgColor: 'bg-amber-900/20' },
  optional: { label: 'Optional', icon: Sparkles, color: '#64748b', bgColor: 'bg-slate-800/40' },
  extras: { label: 'Animated & Multiverse Extras', icon: Zap, color: '#7c3aed', bgColor: 'bg-violet-900/20' },
};

export function DoomsdayTab({ state, onToggleWatched, onSetDoomsdayPlan }: DoomsdayTabProps) {
  const [countdown, setCountdown] = useState(() => getCountdown(DOOMSDAY_RELEASE_DATE));
  const [collapsedSections, setCollapsedSections] = useState<Set<DoomsdayCategory>>(new Set());
  const [detailsTitle, setDetailsTitle] = useState<McuTitle | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown(getCountdown(DOOMSDAY_RELEASE_DATE));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Doomsday plan titles (filtered by selected plan)
  const planEntries = useMemo(() => {
    return DOOMSDAY_PLAN.filter((e) => state.doomsdayPlan === 'full' || e.plan === 'quick' || e.plan === 'both');
  }, [state.doomsdayPlan]);

  const planTitleIds = planEntries.map((e) => e.titleId);
  const planTitles = planTitleIds
    .map((id) => MCU_CATALOGUE.find((t) => t.id === id))
    .filter((t): t is McuTitle => t !== undefined);

  const planWatchedCount = countWatched(state.watched, planTitles);
  const planTotal = planTitles.length;
  const planPercent = calcPercentage(planWatchedCount, planTotal);
  const planWatchedMinutes = getWatchedMinutes(state.watched, planTitles);
  const planRemainingMinutes = planTitles.filter((t) => !state.watched[t.id]).reduce((sum, t) => sum + t.runtimeMinutes, 0);

  // Category stats
  const categoryStats = useMemo(() => {
    const cats: DoomsdayCategory[] = ['core', 'important', 'optional', 'extras'];
    return cats.map((cat) => {
      const catEntries = planEntries.filter((e) => e.category === cat);
      const catTitles = catEntries
        .map((e) => MCU_CATALOGUE.find((t) => t.id === e.titleId))
        .filter((t): t is McuTitle => t !== undefined);
      const watched = countWatched(state.watched, catTitles);
      const remainingMinutes = catTitles.filter((t) => !state.watched[t.id]).reduce((sum, t) => sum + t.runtimeMinutes, 0);
      return {
        category: cat,
        titles: catTitles,
        watched,
        total: catTitles.length,
        percent: calcPercentage(watched, catTitles.length),
        remainingMinutes,
      };
    });
  }, [planEntries, state.watched]);

  const toggleSection = (cat: DoomsdayCategory) => {
    setCollapsedSections((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  const markAllWatched = (titleIds: string[]) => {
    titleIds.forEach((id) => {
      if (!state.watched[id]) onToggleWatched(id);
    });
  };

  return (
    <div className="min-h-screen pb-20 pt-14 bg-gradient-to-b from-[#0c0a08] via-[#120e0c] to-[#0a0808]">
      {/* Header section with countdown */}
      <div className="relative px-4 py-6 overflow-hidden">
        {/* Background energy effects */}
        <div className="absolute inset-0 opacity-40 pointer-events-none">
          <div className="absolute top-10 left-1/2 -translate-x-1/2 w-64 h-64 bg-red-800/15 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-48 h-48 bg-amber-700/10 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10">
          {/* Warning style header */}
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent to-red-700/40" />
            <span className="text-[10px] font-bold tracking-[0.3em] text-red-500/60 uppercase">Mission Briefing</span>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent to-red-700/40" />
          </div>

          <h1 className="text-lg font-black tracking-[0.15em] text-center text-white mb-1">
            ROAD TO <span className="text-red-500">AVENGERS: DOOMSDAY</span>
          </h1>
          <p className="text-xs text-center text-white/40 mb-6">
            Prepare for the next chapter of the Marvel universe.
          </p>

          {/* Countdown */}
          {!countdown.expired ? (
            <div className="mb-6">
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: 'Days', value: countdown.days },
                  { label: 'Hours', value: countdown.hours },
                  { label: 'Minutes', value: countdown.minutes },
                  { label: 'Seconds', value: countdown.seconds },
                ].map((unit) => (
                  <div
                    key={unit.label}
                    className="bg-gradient-to-b from-zinc-900/80 to-zinc-950/80 rounded-xl border border-red-900/20 py-3 text-center"
                  >
                    <div className="text-2xl font-black tabular-nums text-white">
                      {String(unit.value).padStart(2, '0')}
                    </div>
                    <div className="text-[8px] text-red-400/50 uppercase tracking-widest mt-0.5">
                      {unit.label}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-center text-[10px] text-white/30 mt-2">
                Countdown to December 18, 2026 (US release)
              </p>
            </div>
          ) : (
            <div className="mb-6 text-center py-8 bg-zinc-900/50 rounded-xl border border-red-900/20">
              <p className="text-sm text-white/50">Release countdown will appear when the date is confirmed.</p>
            </div>
          )}

          {/* Preparation progress */}
          <div className="flex flex-col items-center mb-4">
            <ProgressRing
              percentage={planPercent}
              size={160}
              strokeWidth={8}
              color="#dc2626"
              label="Doomsday Prep"
            />
          </div>

          {/* Prep summary */}
          <div className="flex justify-center gap-4 mb-5">
            <div className="text-center">
              <div className="text-lg font-bold text-white tabular-nums">{planWatchedCount}</div>
              <div className="text-[10px] text-red-400/50 uppercase tracking-wider">Watched</div>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div className="text-center">
              <div className="text-lg font-bold text-white tabular-nums">{planTotal - planWatchedCount}</div>
              <div className="text-[10px] text-red-400/50 uppercase tracking-wider">Remaining</div>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div className="text-center">
              <div className="text-lg font-bold text-white tabular-nums">{formatHours(planRemainingMinutes)}</div>
              <div className="text-[10px] text-red-400/50 uppercase tracking-wider">Hours Left</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5 mb-5">
            <div className="bg-zinc-900/50 rounded-xl p-3 border border-white/5">
              <div className="text-[10px] text-white/40 uppercase tracking-wider">Watch Time Done</div>
              <div className="text-base font-bold text-white">{formatHours(planWatchedMinutes)}</div>
            </div>
            <div className="bg-zinc-900/50 rounded-xl p-3 border border-white/5">
              <div className="text-[10px] text-white/40 uppercase tracking-wider">Watch Time Left</div>
              <div className="text-base font-bold text-white">{formatHours(planRemainingMinutes)}</div>
            </div>
          </div>

          {/* Plan selector */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => onSetDoomsdayPlan('quick')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                state.doomsdayPlan === 'quick'
                  ? 'bg-red-700 text-white border border-red-500/50'
                  : 'bg-zinc-900/50 text-white/50 border border-white/5'
              }`}
            >
              QUICK PREPARATION
            </button>
            <button
              onClick={() => onSetDoomsdayPlan('full')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                state.doomsdayPlan === 'full'
                  ? 'bg-red-700 text-white border border-red-500/50'
                  : 'bg-zinc-900/50 text-white/50 border border-white/5'
              }`}
            >
              FULL EXPERIENCE
            </button>
          </div>

          <p className="text-[10px] text-white/25 text-center mb-4 leading-relaxed">
            This is editorial fan guidance, not an official Marvel requirement. Not every title is required to understand Doomsday.
          </p>
        </div>
      </div>

      {/* Category sections */}
      <div className="px-4 space-y-4">
        {categoryStats.map((stat) => {
          const config = CATEGORY_CONFIG[stat.category];
          const Icon = config.icon;
          const isCollapsed = collapsedSections.has(stat.category);
          return (
            <div
              key={stat.category}
              className="bg-zinc-900/40 rounded-xl border border-white/5 overflow-hidden"
            >
              {/* Section header */}
              <button
                onClick={() => toggleSection(stat.category)}
                className="w-full flex items-center gap-3 p-3.5"
              >
                <div
                  className="flex items-center justify-center w-9 h-9 rounded-lg flex-shrink-0"
                  style={{ backgroundColor: `${config.color}20`, border: `1px solid ${config.color}30` }}
                >
                  <Icon size={18} style={{ color: config.color }} />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="text-sm font-bold text-white uppercase tracking-wide">{config.label}</div>
                  <div className="text-[10px] text-white/40 mt-0.5">
                    {stat.watched}/{stat.total} watched · {formatHours(stat.remainingMinutes)} left
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold tabular-nums" style={{ color: config.color }}>
                    {stat.percent}%
                  </span>
                </div>
                <ChevronDown
                  size={16}
                  className={`text-white/30 transition-transform ${isCollapsed ? '-rotate-90' : ''}`}
                />
              </button>

              {/* Progress bar */}
              <div className="px-3.5 pb-2">
                <ProgressBar percentage={stat.percent} color={config.color} height={4} />
              </div>

              {/* Mark all button */}
              {!isCollapsed && stat.total > 0 && (
                <div className="px-3.5 pb-2">
                  <button
                    onClick={() => markAllWatched(stat.titles.map((t) => t.id))}
                    className="flex items-center gap-1.5 text-[11px] text-white/40 hover:text-white/70 transition-colors"
                  >
                    <Check size={12} />
                    Mark All as Watched
                  </button>
                </div>
              )}

              {/* Title rows */}
              {!isCollapsed && (
                <div className="space-y-1.5 px-3.5 pb-3.5">
                  {stat.titles.map((title) => {
                    const entry = getDoomsdayEntry(title.id);
                    const isWatched = !!state.watched[title.id];
                    return (
                      <DoomsdayTitleRow
                        key={title.id}
                        title={title}
                        category={stat.category}
                        reason={entry?.reason || ''}
                        watched={isWatched}
                        onToggleWatched={() => onToggleWatched(title.id)}
                        onShowDetails={() => setDetailsTitle(title)}
                        color={config.color}
                      />
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Details modal */}
      {detailsTitle && (
        <DoomsdayDetailsModal
          title={detailsTitle}
          onClose={() => setDetailsTitle(null)}
          watched={!!state.watched[detailsTitle.id]}
          onToggleWatched={() => onToggleWatched(detailsTitle.id)}
        />
      )}
    </div>
  );
}

interface DoomsdayTitleRowProps {
  title: McuTitle;
  category: DoomsdayCategory;
  reason: string;
  watched: boolean;
  onToggleWatched: () => void;
  onShowDetails: () => void;
  color: string;
}

function DoomsdayTitleRow({ title, category, reason, watched, onToggleWatched, onShowDetails, color }: DoomsdayTitleRowProps) {
  const config = CATEGORY_CONFIG[category];
  return (
    <div
      className={`rounded-lg p-3 border transition-all duration-300 ${
        watched ? 'bg-white/[0.01] border-white/5 opacity-50' : 'bg-white/[0.03] border-white/5'
      }`}
    >
      <div className="flex items-start gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className={`text-sm font-semibold ${watched ? 'text-white/60' : 'text-white'}`}>
              {title.title}
            </h4>
            <span className="text-xs text-white/30">({title.year})</span>
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span
              className="text-[9px] font-bold tracking-wider px-1.5 py-0.5 rounded"
              style={{ backgroundColor: `${color}20`, color: config.color }}
            >
              {config.label.toUpperCase()}
            </span>
            <span className="text-[10px] text-white/40 uppercase">{title.type}</span>
            <span className="flex items-center gap-1 text-[10px] text-white/40">
              <Clock size={10} />
              {formatRuntime(title.runtimeMinutes)}
            </span>
          </div>
          <p className="text-[11px] text-white/40 mt-1.5 leading-relaxed line-clamp-2">{reason}</p>
        </div>
        <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
          <WatchedCheckbox watched={watched} onToggle={onToggleWatched} doomsdayTheme />
          <button
            onClick={onShowDetails}
            className="text-[10px] text-white/30 hover:text-white/60 transition-colors flex items-center gap-0.5"
          >
            <Info size={10} />
            Details
          </button>
        </div>
      </div>
    </div>
  );
}

function DoomsdayDetailsModal({
  title,
  onClose,
  watched,
  onToggleWatched,
}: {
  title: McuTitle;
  onClose: () => void;
  watched: boolean;
  onToggleWatched: () => void;
}) {
  const entry = getDoomsdayEntry(title.id);
  const config = entry ? CATEGORY_CONFIG[entry.category] : null;
  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#12100e] rounded-2xl border border-red-900/20 w-full max-w-sm p-5 max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">{title.title}</h3>
          <button onClick={onClose} className="text-white/40 hover:text-white/70">
            <X size={20} />
          </button>
        </div>

        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <span className="text-xs text-white/40">{title.year}</span>
          <span className="text-xs text-white/40">·</span>
          <span className="text-xs text-white/40 uppercase">{title.type}</span>
          <span className="text-xs text-white/40">·</span>
          <span className="flex items-center gap-1 text-xs text-white/40">
            <Clock size={12} />
            {formatRuntime(title.runtimeMinutes)}
          </span>
          {config && (
            <>
              <span className="text-xs text-white/40">·</span>
              <span
                className="text-[10px] font-bold tracking-wider px-1.5 py-0.5 rounded"
                style={{ backgroundColor: `${config.color}20`, color: config.color }}
              >
                {config.label.toUpperCase()}
              </span>
            </>
          )}
        </div>

        <div className="space-y-3">
          <div>
            <span className="text-[10px] text-red-400/50 uppercase tracking-wider block mb-1">Synopsis</span>
            <p className="text-sm text-white/70 leading-relaxed">{title.synopsis}</p>
          </div>
          {entry && (
            <div>
              <span className="text-[10px] text-red-400/50 uppercase tracking-wider block mb-1">
                Why It Matters
              </span>
              <p className="text-sm text-white/70 leading-relaxed">{entry.reason}</p>
            </div>
          )}
          <div>
            <span className="text-[10px] text-red-400/50 uppercase tracking-wider block mb-1">
              Where to Watch
            </span>
            <div className="flex gap-2 flex-wrap">
              {title.whereToWatch.length > 0 ? (
                title.whereToWatch.map((s) => (
                  <span key={s} className="text-xs text-white/50 bg-white/5 px-2 py-1 rounded-md">
                    {s}
                  </span>
                ))
              ) : (
                <span className="text-xs text-white/30">Streaming availability could not be verified.</span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            onToggleWatched();
          }}
          className={`w-full mt-5 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
            watched
              ? 'bg-zinc-800 text-white/60 border border-white/10'
              : 'bg-red-700 text-white border border-red-500/30'
          }`}
        >
          <Check size={16} />
          {watched ? 'Marked as Watched' : 'Mark as Watched'}
        </button>
      </div>
    </div>
  );
}

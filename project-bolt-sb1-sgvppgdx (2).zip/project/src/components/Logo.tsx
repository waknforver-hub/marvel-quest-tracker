interface LogoProps {
  size?: number;
  className?: string;
}

export function MQLogo({ size = 48, className = '' }: LogoProps) {
  return (
    <div
      className={`relative flex items-center justify-center rounded-xl bg-gradient-to-br from-red-700 to-red-900 shadow-lg ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 100 100"
        width={size * 0.6}
        height={size * 0.6}
        fill="none"
      >
        {/* MQ monogram - stylized M with Q circle */}
        <path
          d="M20 70 L20 30 L35 55 L50 30 L50 70"
          stroke="#fbbf24"
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle
          cx="68"
          cy="52"
          r="18"
          stroke="#fbbf24"
          strokeWidth="6"
          fill="none"
        />
        <path
          d="M80 64 L88 72"
          stroke="#fbbf24"
          strokeWidth="6"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}

export function MarvelQuestText({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <MQLogo size={36} />
      <div className="flex flex-col leading-none">
        <span className="text-sm font-black tracking-widest text-white">MARVEL</span>
        <span className="text-sm font-black tracking-widest text-amber-400">QUEST</span>
      </div>
    </div>
  );
}

import { useMemo } from 'react';
import { Film, Tv, Palette, Clock, Layers, Zap, Heart, History, Sparkles, Globe, Swords } from 'lucide-react';
import type { ProgressState, Phase, Universe } from '../types';
import { UNIVERSE_LABELS } from '../types';
import { getReleasedTitles, getTitleById, getTitlesByUniverse, getMcuTitles } from '../data/catalogue';
import {
  countWatched,
  calcPercentage,
  getWatchedMinutes,
  formatHours,
  getTitlesByType,
  getTitlesByPhase,
  getTitlesBySaga,
  getDoomsdayTitles,
} from '../utils/calculations';
import { ProgressRing } from './ProgressRing';
import { ProgressBar } from './ProgressBar';

interface StatusTabProps {
  state: ProgressState;
}

const UNIVERSE_COLORS: Record<string, string> = {
  MCU: '#dc2626',
  'X-MEN': '#0ea5e9',
  'SPIDER-MAN': '#ef4444',
  'SONY MARVEL': '#64748b',
  'FANTASTIC FOUR': '#3b82f6',
  'LEGACY MARVEL': '#f59e0b',
  'MARVEL ANIMATION': '#a855f7',
  'MARVEL ANIME': '#ec4899',
  'OTHER MARVEL': '#22c55e',
};

const UNIVERSE_ORDER: Universe[] = ['MCU', 'X-MEN', 'SPIDER-MAN', 'SONY MARVEL', 'FANTASTIC FOUR', 'LEGACY MARVEL', 'MARVEL ANIMATION', 'MARVEL ANIME', 'OTHER MARVEL'];

export function StatusTab({ state }: StatusTabProps) {
  const releasedTitles = useMemo(() => getReleasedTitles(), []);

  // Overall stats
  const totalTitles = releasedTitles.length;
  const watchedCount = countWatched(state.watched, releasedTitles);
  const unwatchedCount = totalTitles - watchedCount;
  const overallPercent = calcPercentage(watchedCount, totalTitles);
  const watchedMinutes = getWatchedMinutes(state.watched, releasedTitles);
  const remainingMinutes = releasedTitles.filter((t) => !state.watched[t.id]).reduce((s, t) => s + t.runtimeMinutes, 0);
  const daysOfViewing = (watchedMinutes / 60 / 24).toFixed(1);

  // Movies
  const moviesTotal = getTitlesByType('movie').length;
  const moviesWatched = countWatched(state.watched, getTitlesByType('movie'));
  const moviesRemaining = moviesTotal - moviesWatched;
  const moviesPercent = calcPercentage(moviesWatched, moviesTotal);

  // Series
  const seriesTotal = getTitlesByType('series').length;
  const seriesWatched = countWatched(state.watched, getTitlesByType('series'));
  const seriesRemaining = seriesTotal - seriesWatched;
  const seriesPercent = calcPercentage(seriesWatched, seriesTotal);

  // Animation
  const animTotal = getTitlesByType('animation').length;
  const animWatched = countWatched(state.watched, getTitlesByType('animation'));
  const animRemaining = animTotal - animWatched;
  const animPercent = calcPercentage(animWatched, animTotal);

  // Anime
  const animeTotal = getTitlesByType('anime').length;
  const animeWatched = countWatched(state.watched, getTitlesByType('anime'));
  const animeRemaining = animeTotal - animeWatched;
  const animePercent = calcPercentage(animeWatched, animeTotal);

  // Specials
  const specialTotal = getTitlesByType('special').length + getTitlesByType('short').length;
  const specialWatched = countWatched(state.watched, [...getTitlesByType('special'), ...getTitlesByType('short')]);

  // MCU-specific stats
  const mcuTitles = getMcuTitles();
  const mcuWatched = countWatched(state.watched, mcuTitles);
  const mcuPercent = calcPercentage(mcuWatched, mcuTitles.length);

  // Saga progress (MCU)
  const infinityTitles = getTitlesBySaga('Infinity Saga');
  const infinityPercent = calcPercentage(countWatched(state.watched, infinityTitles), infinityTitles.length);
  const multiverseTitles = getTitlesBySaga('Multiverse Saga');
  const multiversePercent = calcPercentage(countWatched(state.watched, multiverseTitles), multiverseTitles.length);

  // Phase progress (MCU)
  const phases: Phase[] = [1, 2, 3, 4, 5, 6];
  const phaseProgress = phases.map((p) => {
    const phaseTitles = getTitlesByPhase(p);
    return {
      phase: p,
      total: phaseTitles.length,
      watched: countWatched(state.watched, phaseTitles),
      percent: calcPercentage(countWatched(state.watched, phaseTitles), phaseTitles.length),
    };
  });

  // Doomsday progress
  const doomsdayTitles = getDoomsdayTitles();
  const doomsdayPercent = calcPercentage(countWatched(state.watched, doomsdayTitles), doomsdayTitles.length);
  const coreTitles = getDoomsdayTitles('core');
  const corePercent = calcPercentage(countWatched(state.watched, coreTitles), coreTitles.length);
  const importantTitles = getDoomsdayTitles('important');
  const importantPercent = calcPercentage(countWatched(state.watched, importantTitles), importantTitles.length);
  const optionalTitles = getDoomsdayTitles('optional');
  const optionalPercent = calcPercentage(countWatched(state.watched, optionalTitles), optionalTitles.length);
  const doomsdayRemainingMinutes = doomsdayTitles.filter((t) => !state.watched[t.id]).reduce((s, t) => s + t.runtimeMinutes, 0);

  // Universe progress
  const universeProgress = UNIVERSE_ORDER.map((u) => {
    const titles = getTitlesByUniverse(u);
    return {
      universe: u,
      total: titles.length,
      watched: countWatched(state.watched, titles),
      percent: calcPercentage(countWatched(state.watched, titles), titles.length),
      color: UNIVERSE_COLORS[u] || '#64748b',
    };
  }).filter((u) => u.total > 0);

  // Favorites & history
  const favoriteTitles = state.favorites.map((id) => getTitleById(id)).filter((t): t is NonNullable<typeof t> => t !== undefined);
  const recentTitles = state.recentlyWatched.map((id) => getTitleById(id)).filter((t): t is NonNullable<typeof t> => t !== undefined).slice(0, 5);

  return (
    <div className="min-h-screen pb-20 pt-14">
      <div className="px-4 py-6">
        <h1 className="text-xs font-bold tracking-[0.25em] text-white/50 uppercase mb-1">
          Your Marvel Status
        </h1>
        <p className="text-[11px] text-white/30 mb-6">Detailed statistics from your Marvel Universe journey</p>

        {/* Main completion ring */}
        <div className="flex flex-col items-center mb-6">
          <ProgressRing
            percentage={overallPercent}
            size={180}
            strokeWidth={10}
            color="#dc2626"
            label="Universe Completion"
          />
        </div>

        {/* Top stats */}
        <div className="flex justify-center gap-4 mb-6">
          <div className="text-center">
            <div className="text-xl font-bold text-white tabular-nums">{totalTitles}</div>
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Total</div>
          </div>
          <div className="w-px h-10 bg-white/10" />
          <div className="text-center">
            <div className="text-xl font-bold text-white tabular-nums">{watchedCount}</div>
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Watched</div>
          </div>
          <div className="w-px h-10 bg-white/10" />
          <div className="text-center">
            <div className="text-xl font-bold text-white tabular-nums">{unwatchedCount}</div>
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Unwatched</div>
          </div>
        </div>

        {/* Content type cards */}
        <div className="space-y-3 mb-6">
          <StatCard
            icon={Film}
            iconColor="#3b82f6"
            label="Movies"
            stats={[
              { label: 'Total', value: String(moviesTotal) },
              { label: 'Watched', value: String(moviesWatched) },
              { label: 'Remaining', value: String(moviesRemaining) },
            ]}
            percent={moviesPercent}
          />
          <StatCard
            icon={Tv}
            iconColor="#22c55e"
            label="Series"
            stats={[
              { label: 'Total', value: String(seriesTotal) },
              { label: 'Completed', value: String(seriesWatched) },
              { label: 'Not Started', value: String(seriesRemaining) },
            ]}
            percent={seriesPercent}
          />
          <StatCard
            icon={Palette}
            iconColor="#a855f7"
            label="Animation"
            stats={[
              { label: 'Total', value: String(animTotal) },
              { label: 'Watched', value: String(animWatched) },
              { label: 'Remaining', value: String(animRemaining) },
            ]}
            percent={animPercent}
          />
          <StatCard
            icon={Swords}
            iconColor="#ec4899"
            label="Anime"
            stats={[
              { label: 'Total', value: String(animeTotal) },
              { label: 'Watched', value: String(animeWatched) },
              { label: 'Remaining', value: String(animeRemaining) },
            ]}
            percent={animePercent}
          />
          {specialTotal > 0 && (
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles size={16} className="text-amber-400" />
                <span className="text-sm font-semibold text-white">Specials & Shorts</span>
              </div>
              <div className="flex gap-4 text-xs">
                <span className="text-white/40">Total: <span className="text-white font-medium">{specialTotal}</span></span>
                <span className="text-white/40">Watched: <span className="text-white font-medium">{specialWatched}</span></span>
              </div>
            </div>
          )}
        </div>

        {/* Watch time */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Clock size={16} className="text-amber-400" />
            <span className="text-sm font-semibold text-white">Watch Time</span>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <div className="text-lg font-bold text-white">{formatHours(watchedMinutes)}</div>
              <div className="text-[10px] text-white/40">Watched</div>
            </div>
            <div>
              <div className="text-lg font-bold text-white">{formatHours(remainingMinutes)}</div>
              <div className="text-[10px] text-white/40">Remaining</div>
            </div>
            <div>
              <div className="text-lg font-bold text-white">{daysOfViewing}</div>
              <div className="text-[10px] text-white/40">Days of viewing</div>
            </div>
          </div>
        </div>

        {/* Universe progress */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Globe size={16} className="text-amber-400" />
            <span className="text-sm font-semibold text-white">Universe Progress</span>
          </div>
          <div className="space-y-3">
            {universeProgress.map((u) => (
              <div key={u.universe}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-white/60">{UNIVERSE_LABELS[u.universe]}</span>
                  <span className="text-[10px] text-white/40 tabular-nums">
                    {u.watched}/{u.total} · {u.percent}%
                  </span>
                </div>
                <ProgressBar percentage={u.percent} color={u.color} height={4} />
              </div>
            ))}
          </div>
        </div>

        {/* MCU-specific progress */}
        <div className="bg-red-950/10 backdrop-blur-sm rounded-xl p-4 border border-red-900/20 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white">MCU Progress</span>
            </div>
            <span className="text-sm font-bold text-red-400 tabular-nums">{mcuPercent}%</span>
          </div>
          <div className="text-[10px] text-white/40 mb-3">{mcuWatched} of {mcuTitles.length} MCU titles watched</div>

          {/* Saga progress */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs text-white/60">Infinity Saga</span>
                <span className="text-xs font-bold text-white tabular-nums">{infinityPercent}%</span>
              </div>
              <ProgressBar percentage={infinityPercent} color="#f59e0b" height={5} />
            </div>
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs text-white/60">Multiverse Saga</span>
                <span className="text-xs font-bold text-white tabular-nums">{multiversePercent}%</span>
              </div>
              <ProgressBar percentage={multiversePercent} color="#dc2626" height={5} />
            </div>
          </div>

          {/* Phase progress */}
          <div className="mt-4 pt-3 border-t border-white/5">
            <div className="flex items-center gap-2 mb-3">
              <Layers size={14} className="text-amber-400" />
              <span className="text-xs font-semibold text-white/70">Phase Progress</span>
            </div>
            <div className="space-y-2.5">
              {phaseProgress.map((p) => (
                <div key={p.phase}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[11px] text-white/60">Phase {p.phase}</span>
                    <span className="text-[10px] text-white/40 tabular-nums">
                      {p.watched}/{p.total} · {p.percent}%
                    </span>
                  </div>
                  <ProgressBar percentage={p.percent} color="#dc2626" height={3} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Doomsday progress */}
        <div className="bg-red-950/20 backdrop-blur-sm rounded-xl p-4 border border-red-900/20 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={16} className="text-red-400" />
            <span className="text-sm font-semibold text-white">Doomsday Preparation</span>
          </div>
          <div className="flex flex-col items-center mb-4">
            <ProgressRing percentage={doomsdayPercent} size={120} strokeWidth={7} color="#dc2626" />
          </div>
          <div className="space-y-3">
            <DoomsdayProgressRow label="Core" percent={corePercent} color="#dc2626" />
            <DoomsdayProgressRow label="Important" percent={importantPercent} color="#f59e0b" />
            <DoomsdayProgressRow label="Optional" percent={optionalPercent} color="#64748b" />
            <div className="pt-2 border-t border-white/5">
              <div className="flex justify-between text-xs">
                <span className="text-white/50">Estimated remaining hours</span>
                <span className="text-white font-bold">{formatHours(doomsdayRemainingMinutes)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Favorites & History */}
        <div className="space-y-3">
          {favoriteTitles.length > 0 && (
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 mb-3">
                <Heart size={16} className="text-amber-400" />
                <span className="text-sm font-semibold text-white">Favourites ({favoriteTitles.length})</span>
              </div>
              <div className="space-y-1.5">
                {favoriteTitles.slice(0, 8).map((t) => (
                  <div key={t.id} className="flex items-center justify-between text-xs">
                    <span className="text-white/70">{t.title}</span>
                    <span className="text-white/30">{t.year}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {recentTitles.length > 0 && (
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 mb-3">
                <History size={16} className="text-amber-400" />
                <span className="text-sm font-semibold text-white">Recently Watched</span>
              </div>
              <div className="space-y-1.5">
                {recentTitles.map((t, i) => (
                  <div key={t.id} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2">
                      <span className="text-white/30 tabular-nums">{i + 1}.</span>
                      <span className="text-white/70">{t.title}</span>
                    </span>
                    <span className="text-white/30">{t.year}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {favoriteTitles.length === 0 && recentTitles.length === 0 && (
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 text-center">
              <p className="text-sm text-white/30">
                Start watching titles to see your favourites and recently watched history here.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  iconColor,
  label,
  stats,
  percent,
}: {
  icon: typeof Film;
  iconColor: string;
  label: string;
  stats: { label: string; value: string }[];
  percent: number;
}) {
  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon size={16} style={{ color: iconColor }} />
          <span className="text-sm font-semibold text-white">{label}</span>
        </div>
        <span className="text-sm font-bold tabular-nums" style={{ color: iconColor }}>
          {percent}%
        </span>
      </div>
      <ProgressBar percentage={percent} color={iconColor} height={5} />
      <div className="flex gap-4 mt-3">
        {stats.map((s) => (
          <div key={s.label}>
            <span className="text-xs text-white/40">{s.label}: </span>
            <span className="text-xs font-medium text-white">{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function DoomsdayProgressRow({ label, percent, color }: { label: string; percent: number; color: string }) {
  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs text-white/60">{label}</span>
        <span className="text-xs font-bold tabular-nums" style={{ color }}>
          {percent}%
        </span>
      </div>
      <ProgressBar percentage={percent} color={color} height={4} />
    </div>
  );
}

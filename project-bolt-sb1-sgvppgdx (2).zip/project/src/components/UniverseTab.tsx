import { useMemo, useState } from 'react';
import { Search, X, Play, Clock, Star, ChevronDown, ArrowUpDown, Heart, RotateCcw } from 'lucide-react';
import type { ProgressState, McuTitle, ContentType, Phase, Saga, Universe } from '../types';
import { UNIVERSE_LABELS } from '../types';
import { getReleasedTitles, getMcuTitles, getTitlesByUniverse } from '../data/catalogue';
import {
  countWatched,
  calcPercentage,
  getWatchedMinutes,
  formatRuntime,
  formatHours,
  filterTitles,
  searchTitles,
  sortTitles,
  getTitlesByType,
} from '../utils/calculations';
import { ProgressRing } from './ProgressRing';
import { WatchedCheckbox } from './WatchedCheckbox';

interface UniverseTabProps {
  state: ProgressState;
  onToggleWatched: (id: string) => void;
  onToggleInProgress: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onSetFilters: (filters: Partial<ProgressState['filters']>) => void;
  onResetFilters: () => void;
  onSetWatchOrder: (order: 'release' | 'chronological') => void;
}

const TYPE_LABELS: Record<string, string> = {
  ALL: 'All',
  movie: 'Movies',
  series: 'Series',
  animation: 'Animation',
  anime: 'Anime',
  special: 'Specials',
  short: 'Shorts',
};

const TYPE_BADGE: Record<string, string> = {
  movie: 'MOVIE',
  series: 'SERIES',
  animation: 'ANIMATION',
  anime: 'ANIME',
  special: 'SPECIAL',
  short: 'SHORT',
};

const UNIVERSE_COLORS: Record<string, string> = {
  MCU: '#dc2626',
  'X-MEN': '#0ea5e9',
  'SPIDER-MAN': '#ef4444',
  'SONY MARVEL': '#64748b',
  'FANTASTIC FOUR': '#3b82f6',
  'LEGACY MARVEL': '#f59e0b',
  'MARVEL ANIMATION': '#a855f7',
  'MARVEL ANIME': '#ec4899',
  'OTHER MARVEL': '#22c55e',
};

const UNIVERSE_SUMMARY: { key: Universe; label: string; color: string }[] = [
  { key: 'MCU', label: 'MCU', color: '#dc2626' },
  { key: 'X-MEN', label: 'X-Men', color: '#0ea5e9' },
  { key: 'SPIDER-MAN', label: 'Spider-Man', color: '#ef4444' },
  { key: 'FANTASTIC FOUR', label: 'Fantastic Four', color: '#3b82f6' },
  { key: 'MARVEL ANIMATION', label: 'Animation', color: '#a855f7' },
  { key: 'MARVEL ANIME', label: 'Anime', color: '#ec4899' },
  { key: 'OTHER MARVEL', label: 'Other', color: '#22c55e' },
];

export function UniverseTab({
  state,
  onToggleWatched,
  onToggleFavorite,
  onSetFilters,
  onResetFilters,
  onSetWatchOrder,
}: UniverseTabProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [whereToWatchTitle, setWhereToWatchTitle] = useState<McuTitle | null>(null);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());

  const releasedTitles = useMemo(() => getReleasedTitles(), []);

  // Dashboard stats
  const totalReleased = releasedTitles.length;
  const watchedCount = countWatched(state.watched, releasedTitles);
  const remainingCount = totalReleased - watchedCount;
  const overallPercent = calcPercentage(watchedCount, totalReleased);
  const watchedMinutes = getWatchedMinutes(state.watched, releasedTitles);

  const moviesWatched = countWatched(state.watched, getTitlesByType('movie'));
  const moviesTotal = getTitlesByType('movie').length;
  const seriesWatched = countWatched(state.watched, getTitlesByType('series'));
  const seriesTotal = getTitlesByType('series').length;
  const remainingMinutes = releasedTitles
    .filter((t) => !state.watched[t.id])
    .reduce((sum, t) => sum + t.runtimeMinutes, 0);

  // Filtered + searched + sorted catalogue
  const filteredTitles = useMemo(() => {
    let result = filterTitles(releasedTitles, state.filters, state.watched, state.inProgress);
    result = searchTitles(result, searchQuery);
    result = sortTitles(result, state.watchOrder);
    return result;
  }, [releasedTitles, state.filters, state.watched, state.inProgress, searchQuery, state.watchOrder]);

  // Group by category
  const groupedByCategory = useMemo(() => {
    const groups: Record<string, McuTitle[]> = {};
    for (const title of filteredTitles) {
      const key = title.category || title.universe || 'Other';
      if (!groups[key]) groups[key] = [];
      groups[key].push(title);
    }
    return groups;
  }, [filteredTitles]);

  const toggleGroupCollapse = (key: string) => {
    setCollapsedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const typeFilterOptions: ('ALL' | ContentType)[] = ['ALL', 'movie', 'series', 'animation', 'anime', 'special', 'short'];
  const universeOptions: ('ALL' | Universe)[] = ['ALL', 'MCU', 'X-MEN', 'SPIDER-MAN', 'SONY MARVEL', 'FANTASTIC FOUR', 'LEGACY MARVEL', 'MARVEL ANIMATION', 'MARVEL ANIME', 'OTHER MARVEL'];
  const phaseOptions: ('ALL' | Phase)[] = ['ALL', 1, 2, 3, 4, 5, 6];
  const sagaOptions: ('ALL' | Saga)[] = ['ALL', 'Infinity Saga', 'Multiverse Saga'];

  const hasActiveFilters =
    state.filters.universe !== 'ALL' ||
    state.filters.phase !== 'ALL' ||
    state.filters.saga !== 'ALL' ||
    state.filters.watched !== 'ALL' ||
    state.filters.type !== 'ALL';

  return (
    <div className="min-h-screen pb-20 pt-14">
      {/* Dashboard section */}
      <div className="px-4 py-6">
        <h1 className="text-xs font-bold tracking-[0.25em] text-white/50 uppercase mb-1">
          Marvel Universe
        </h1>
        <p className="text-[11px] text-white/30 mb-6">Track your journey through every Marvel screen title</p>

        {/* Main progress ring */}
        <div className="flex flex-col items-center mb-6">
          <ProgressRing
            percentage={overallPercent}
            size={180}
            strokeWidth={10}
            color="#dc2626"
            label="Universe Completion"
          />
        </div>

        {/* Count summary */}
        <div className="flex justify-center gap-6 mb-5">
          <div className="text-center">
            <div className="text-2xl font-bold text-white tabular-nums">{watchedCount}</div>
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Watched</div>
          </div>
          <div className="w-px h-12 bg-white/10" />
          <div className="text-center">
            <div className="text-2xl font-bold text-white tabular-nums">{remainingCount}</div>
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Remaining</div>
          </div>
          <div className="w-px h-12 bg-white/10" />
          <div className="text-center">
            <div className="text-2xl font-bold text-white tabular-nums">{totalReleased}</div>
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Total Titles</div>
          </div>
        </div>

        {/* Compact summary cards */}
        <div className="grid grid-cols-2 gap-2.5 mb-4">
          <SummaryCard label="Movies" value={`${moviesWatched}/${moviesTotal}`} sublabel="watched" />
          <SummaryCard label="Series" value={`${seriesWatched}/${seriesTotal}`} sublabel="watched" />
          <SummaryCard label="Watch Time" value={formatHours(watchedMinutes)} sublabel="completed" />
          <SummaryCard label="Remaining" value={formatHours(remainingMinutes)} sublabel="to watch" />
        </div>

        {/* Universe progress cards */}
        <div className="grid grid-cols-2 gap-2.5 mb-6">
          {UNIVERSE_SUMMARY.map(({ key, label, color }) => {
            const universeTitles = getTitlesByUniverse(key);
            const uniWatched = countWatched(state.watched, universeTitles);
            const uniPercent = calcPercentage(uniWatched, universeTitles.length);
            return (
              <div key={key} className="bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] text-white/50 uppercase tracking-wider font-medium">{label}</span>
                  <span className="text-xs font-bold tabular-nums" style={{ color }}>{uniPercent}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-sm font-bold text-white tabular-nums">{uniWatched}</div>
                  <span className="text-[10px] text-white/30">/ {universeTitles.length}</span>
                </div>
                <div className="mt-2 h-1 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${uniPercent}%`, background: color }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter bar */}
      <div className="sticky top-14 z-30 bg-[#0a0e17]/95 backdrop-blur-md border-y border-white/10 px-4 py-3 mb-2">
        {/* Type filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide mb-2">
          {typeFilterOptions.map((opt) => (
            <button
              key={opt}
              onClick={() => onSetFilters({ type: opt })}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                state.filters.type === opt
                  ? 'bg-red-600 text-white'
                  : 'bg-white/5 text-white/50 hover:bg-white/10'
              }`}
            >
              {TYPE_LABELS[opt]}
            </button>
          ))}
        </div>

        {/* Action row */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSearch(!showSearch)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              showSearch || searchQuery ? 'bg-white/10 text-white' : 'bg-white/5 text-white/50'
            }`}
          >
            <Search size={14} />
          </button>

          <button
            onClick={() => onSetWatchOrder(state.watchOrder === 'release' ? 'chronological' : 'release')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 text-white/60 hover:bg-white/10 transition-all"
          >
            <ArrowUpDown size={14} />
            {state.watchOrder === 'release' ? 'Release' : 'Chronological'}
          </button>

          {hasActiveFilters && (
            <button
              onClick={onResetFilters}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-white/5 text-white/50 hover:text-red-400 transition-all"
            >
              <RotateCcw size={12} />
              Reset
            </button>
          )}

          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ml-auto ${
              showAdvanced || hasActiveFilters
                ? 'bg-amber-900/30 text-amber-400 border border-amber-700/30'
                : 'bg-white/5 text-white/50'
            }`}
          >
            Filters
            <ChevronDown size={14} className={showAdvanced ? 'rotate-180' : ''} />
          </button>
        </div>

        {/* Search bar */}
        {showSearch && (
          <div className="mt-2 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search titles..."
              autoFocus
              className="w-full bg-white/5 border border-white/10 rounded-lg px-9 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-red-500/50"
            />
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
              >
                <X size={16} />
              </button>
            )}
          </div>
        )}

        {/* Advanced filters */}
        {showAdvanced && (
          <div className="mt-3 space-y-2.5 pt-2 border-t border-white/10">
            {/* Universe */}
            <div>
              <span className="text-[10px] text-white/40 uppercase tracking-wider mb-1.5 block">Universe</span>
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide">
                {universeOptions.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => onSetFilters({ universe: opt })}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all ${
                      state.filters.universe === opt ? 'bg-amber-600 text-white' : 'bg-white/5 text-white/40'
                    }`}
                  >
                    {opt === 'ALL' ? 'All Universes' : UNIVERSE_LABELS[opt as Universe]}
                  </button>
                ))}
              </div>
            </div>
            {/* Phase */}
            <div>
              <span className="text-[10px] text-white/40 uppercase tracking-wider mb-1.5 block">Phase (MCU)</span>
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide">
                {phaseOptions.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => onSetFilters({ phase: opt })}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all ${
                      state.filters.phase === opt ? 'bg-amber-600 text-white' : 'bg-white/5 text-white/40'
                    }`}
                  >
                    {opt === 'ALL' ? 'All' : `Phase ${opt}`}
                  </button>
                ))}
              </div>
            </div>
            {/* Saga */}
            <div>
              <span className="text-[10px] text-white/40 uppercase tracking-wider mb-1.5 block">Saga (MCU)</span>
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide">
                {sagaOptions.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => onSetFilters({ saga: opt })}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all ${
                      state.filters.saga === opt ? 'bg-amber-600 text-white' : 'bg-white/5 text-white/40'
                    }`}
                  >
                    {opt === 'ALL' ? 'All' : opt}
                  </button>
                ))}
              </div>
            </div>
            {/* Watched */}
            <div>
              <span className="text-[10px] text-white/40 uppercase tracking-wider mb-1.5 block">Status</span>
              <div className="flex items-center gap-1.5">
                {(['ALL', 'watched', 'unwatched', 'in_progress'] as const).map((opt) => (
                  <button
                    key={opt}
                    onClick={() => onSetFilters({ watched: opt })}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${
                      state.filters.watched === opt ? 'bg-amber-600 text-white' : 'bg-white/5 text-white/40'
                    }`}
                  >
                    {opt === 'ALL' ? 'All' : opt === 'watched' ? 'Watched' : opt === 'unwatched' ? 'Unwatched' : 'In Progress'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Title count */}
      <div className="px-4 pb-2">
        <span className="text-xs text-white/40">
          {filteredTitles.length} {filteredTitles.length === 1 ? 'title' : 'titles'}
        </span>
      </div>

      {/* Catalogue list grouped by category */}
      <div className="px-4 space-y-4">
        {filteredTitles.length === 0 && (
          <div className="text-center py-16 text-white/30">
            <p className="text-sm">No titles match your filters.</p>
          </div>
        )}
        {Object.entries(groupedByCategory).map(([groupKey, titles]) => (
          <div key={groupKey}>
            <button
              onClick={() => toggleGroupCollapse(groupKey)}
              className="w-full flex items-center justify-between py-2 px-3 rounded-lg bg-white/5 mb-2"
            >
              <span className="text-xs font-bold tracking-wider text-white/70 uppercase">{groupKey}</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-white/30 tabular-nums">
                  {countWatched(state.watched, titles)}/{titles.length}
                </span>
                <ChevronDown
                  size={14}
                  className={`text-white/30 transition-transform ${collapsedGroups.has(groupKey) ? '-rotate-90' : ''}`}
                />
              </div>
            </button>
            {!collapsedGroups.has(groupKey) && (
              <div className="space-y-2">
                {titles.map((title, idx) => (
                  <TitleRow
                    key={title.id}
                    title={title}
                    index={idx + 1}
                    watched={!!state.watched[title.id]}
                    isFavorite={state.favorites.includes(title.id)}
                    onToggleWatched={() => onToggleWatched(title.id)}
                    onToggleFavorite={() => onToggleFavorite(title.id)}
                    onWhereToWatch={() => setWhereToWatchTitle(title)}
                  />
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Where to watch modal */}
      {whereToWatchTitle && (
        <WhereToWatchModal title={whereToWatchTitle} onClose={() => setWhereToWatchTitle(null)} />
      )}
    </div>
  );
}

function SummaryCard({ label, value, sublabel }: { label: string; value: string; sublabel: string }) {
  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
      <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">{label}</div>
      <div className="text-lg font-bold text-white tabular-nums">{value}</div>
      <div className="text-[10px] text-white/30">{sublabel}</div>
    </div>
  );
}

interface TitleRowProps {
  title: McuTitle;
  index: number;
  watched: boolean;
  isFavorite: boolean;
  onToggleWatched: () => void;
  onToggleFavorite: () => void;
  onWhereToWatch: () => void;
}

function TitleRow({ title, index, watched, isFavorite, onToggleWatched, onToggleFavorite, onWhereToWatch }: TitleRowProps) {
  const universeColor = title.universe ? UNIVERSE_COLORS[title.universe] || '#64748b' : '#64748b';
  return (
    <div
      className={`rounded-xl p-3.5 border transition-all duration-300 ${
        watched
          ? 'bg-white/[0.02] border-white/5 opacity-60'
          : 'bg-white/[0.04] border-white/10'
      }`}
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 flex flex-col items-center gap-1">
          <span className="text-xs font-bold text-white/30 tabular-nums w-6 text-right">{index}</span>
        </div>

        <div className="flex-1 min-w-0">
          {/* Title line */}
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className={`text-sm font-semibold ${watched ? 'text-white/60' : 'text-white'}`}>
              {title.title}
            </h3>
            <span className="text-xs text-white/30">({title.year})</span>
          </div>

          {/* Type badge + Universe badge */}
          <div className="mt-1 flex items-center gap-2 flex-wrap">
            <span
              className={`text-[9px] font-bold tracking-wider px-1.5 py-0.5 rounded ${
                title.type === 'movie'
                  ? 'bg-blue-900/30 text-blue-400'
                  : title.type === 'series'
                    ? 'bg-green-900/30 text-green-400'
                    : title.type === 'animation'
                      ? 'bg-purple-900/30 text-purple-400'
                      : title.type === 'anime'
                        ? 'bg-pink-900/30 text-pink-400'
                        : 'bg-amber-900/30 text-amber-400'
              }`}
            >
              {TYPE_BADGE[title.type]}
            </span>
            {title.universe && (
              <span
                className="text-[9px] font-bold tracking-wider px-1.5 py-0.5 rounded"
                style={{ backgroundColor: `${universeColor}25`, color: universeColor }}
              >
                {UNIVERSE_LABELS[title.universe]}
              </span>
            )}
            {title.phase && (
              <span className="text-[9px] text-white/30 font-medium">Phase {title.phase}</span>
            )}
          </div>

          {/* Meta info */}
          <div className="mt-2 flex items-center gap-3 flex-wrap">
            <span className="flex items-center gap-1 text-[11px] text-white/40">
              <Clock size={11} />
              {formatRuntime(title.runtimeMinutes)}
            </span>
            {title.episodes && (
              <span className="text-[11px] text-white/40">
                {title.episodes} ep{title.episodes > 1 ? 's' : ''}
              </span>
            )}
            {title.rating !== null && (
              <span className="flex items-center gap-1 text-[11px] text-white/40">
                <Star size={11} className="text-amber-500" />
                {title.rating}/10
                <span className="text-white/20">· {title.ratingSource}</span>
              </span>
            )}
          </div>

          {/* Synopsis */}
          <p className="mt-2 text-xs text-white/50 leading-relaxed">{title.synopsis}</p>

          {/* Actions */}
          <div className="mt-3 flex items-center justify-between">
            <button
              onClick={onWhereToWatch}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 text-[11px] font-medium text-white/60 hover:bg-white/10 transition-all"
            >
              <Play size={12} />
              Where to Watch
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={onToggleFavorite}
                className={`flex items-center justify-center w-8 h-8 rounded-lg transition-all active:scale-90 ${
                  isFavorite
                    ? 'text-amber-400 bg-amber-900/20'
                    : 'text-white/25 hover:text-white/50'
                }`}
                aria-label="Toggle favorite"
              >
                <Heart size={16} fill={isFavorite ? 'currentColor' : 'none'} />
              </button>
              <WatchedCheckbox watched={watched} onToggle={onToggleWatched} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function WhereToWatchModal({ title, onClose }: { title: McuTitle; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#121822] rounded-2xl border border-white/10 w-full max-w-sm p-5 max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">Where to Watch</h3>
          <button onClick={onClose} className="text-white/40 hover:text-white/70">
            <X size={20} />
          </button>
        </div>
        <p className="text-sm text-white/70 mb-1">{title.title}</p>
        <p className="text-xs text-white/40 mb-4">
          {title.year} · {TYPE_BADGE[title.type]} · {formatRuntime(title.runtimeMinutes)}
        </p>
        <div className="space-y-2">
          {title.whereToWatch.length > 0 && !title.whereToWatch.includes('Not available') ? (
            title.whereToWatch.map((service) => (
              <div
                key={service}
                className="flex items-center gap-3 bg-white/5 rounded-lg p-3 border border-white/10"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-white/10 to-white/5 flex items-center justify-center flex-shrink-0">
                  <Play size={18} className="text-white/50" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-white">{service}</div>
                  <div className="text-[11px] text-white/40">Streaming · US region</div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-white/40 text-center py-6">
              Streaming availability could not be verified.
            </p>
          )}
        </div>
        <p className="text-[10px] text-white/25 mt-4 text-center leading-relaxed">
          Availability may vary by country. This is informational only and does not provide direct playback.
        </p>
      </div>
    </div>
  );
}

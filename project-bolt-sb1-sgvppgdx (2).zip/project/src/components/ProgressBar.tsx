interface ProgressBarProps {
  percentage: number;
  color?: string;
  height?: number;
  showLabel?: boolean;
  label?: string;
}

export function ProgressBar({
  percentage,
  color = '#dc2626',
  height = 6,
  showLabel = false,
  label,
}: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, percentage));
  return (
    <div className="w-full">
      {showLabel && (
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-xs text-white/60 uppercase tracking-wider">{label}</span>
          <span className="text-xs font-semibold tabular-nums text-white/80">{clamped}%</span>
        </div>
      )}
      <div
        className="w-full rounded-full overflow-hidden bg-white/10"
        style={{ height }}
      >
        <div
          className="rounded-full transition-all duration-1000 ease-out"
          style={{
            width: `${clamped}%`,
            height: '100%',
            background: `linear-gradient(90deg, ${color}aa, ${color})`,
            boxShadow: `0 0 8px ${color}66`,
          }}
        />
      </div>
    </div>
  );
}

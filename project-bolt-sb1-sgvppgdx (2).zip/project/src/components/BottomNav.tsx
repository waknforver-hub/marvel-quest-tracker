import { Clapperboard, Zap, BarChart3, User } from 'lucide-react';
import type { TabName } from '../types';
import { MQLogo } from './Logo';

interface BottomNavProps {
  activeTab: TabName;
  onTabChange: (tab: TabName) => void;
  onProfileClick: () => void;
  doomsdayActive: boolean;
}

export function BottomNav({ activeTab, onTabChange, onProfileClick, doomsdayActive }: BottomNavProps) {
  const tabs: { id: TabName; label: string; icon: typeof Clapperboard }[] = [
    { id: 'universe', label: 'MARVEL UNIVERSE', icon: Clapperboard },
    { id: 'doomsday', label: 'DOOMSDAY', icon: Zap },
    { id: 'status', label: 'STATUS', icon: BarChart3 },
  ];

  return (
    <>
      {/* Top bar */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-[#0a0e17]/90 backdrop-blur-md border-b border-white/10 pt-[env(safe-area-inset-top)]">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-2">
            <MQLogo size={28} />
            <div className="flex flex-col leading-none">
              <span className="text-xs font-black tracking-widest text-white">MARVEL</span>
              <span className="text-xs font-black tracking-widest text-amber-400">QUEST</span>
            </div>
          </div>
          <button
            onClick={onProfileClick}
            className="flex items-center justify-center w-10 h-10 rounded-full bg-white/10 border border-white/15 active:scale-90 transition-transform hover:bg-white/15"
            aria-label="Profile"
          >
            <User size={18} className="text-white/70" />
          </button>
        </div>
      </div>

      {/* Bottom navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#0a0e17]/95 backdrop-blur-lg border-t border-white/10 pb-[env(safe-area-inset-bottom)]">
        <div className="flex items-center justify-around h-16 px-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            const isDoomsdayTab = tab.id === 'doomsday';
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="flex flex-col items-center justify-center gap-1 flex-1 h-full active:scale-90 transition-transform"
              >
                <div
                  className={`relative flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-300 ${
                    active
                      ? isDoomsdayTab
                        ? 'bg-red-900/40'
                        : 'bg-white/10'
                      : ''
                  }`}
                >
                  <Icon
                    size={20}
                    className={`transition-colors ${
                      active
                        ? isDoomsdayTab
                          ? 'text-red-400'
                          : 'text-amber-400'
                        : 'text-white/40'
                    }`}
                  />
                  {active && (
                    <div
                      className={`absolute -bottom-0.5 w-1 h-1 rounded-full ${
                        isDoomsdayTab ? 'bg-red-400' : 'bg-amber-400'
                      }`}
                    />
                  )}
                </div>
                <span
                  className={`text-[10px] font-semibold tracking-wider transition-colors ${
                    active
                      ? isDoomsdayTab
                        ? 'text-red-400'
                        : 'text-amber-400'
                      : 'text-white/40'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}

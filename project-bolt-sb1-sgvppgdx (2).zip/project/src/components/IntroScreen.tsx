import { Film, Compass, Zap, TrendingUp, ChevronRight } from 'lucide-react';
import { MQLogo } from './Logo';

interface IntroScreenProps {
  onStart: () => void;
  onSkip: () => void;
}

export function IntroScreen({ onStart, onSkip }: IntroScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0e17] via-[#0d1320] to-[#0a0e17] flex flex-col items-center justify-center px-6 py-10 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <div className="absolute top-1/4 -left-20 w-72 h-72 bg-red-900/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-72 h-72 bg-amber-900/15 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 flex flex-col items-center max-w-sm w-full">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <MQLogo size={80} className="mb-4 shadow-2xl" />
          <h1 className="text-3xl font-black tracking-[0.2em] text-white text-center">
            MARVEL QUEST
          </h1>
          <div className="h-px w-24 bg-gradient-to-r from-transparent via-amber-500 to-transparent mt-3 mb-3" />
          <p className="text-sm text-white/60 text-center leading-relaxed">
            Your Marvel journey. Your progress.<br />
            Your path to Doomsday.
          </p>
        </div>

        {/* Feature cards */}
        <div className="space-y-3 w-full mb-8">
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-sm rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-red-900/30 border border-red-700/30 flex-shrink-0">
              <Film size={20} className="text-red-400" />
            </div>
            <p className="text-sm text-white/80">Track the Marvel movies and series you watch</p>
          </div>
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-sm rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-amber-900/30 border border-amber-700/30 flex-shrink-0">
              <Compass size={20} className="text-amber-400" />
            </div>
            <p className="text-sm text-white/80">Explore the Marvel Cinematic Universe</p>
          </div>
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-sm rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-red-900/30 border border-red-700/30 flex-shrink-0">
              <Zap size={20} className="text-red-400" />
            </div>
            <p className="text-sm text-white/80">Prepare for Avengers: Doomsday</p>
          </div>
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-sm rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-amber-900/30 border border-amber-700/30 flex-shrink-0">
              <TrendingUp size={20} className="text-amber-400" />
            </div>
            <p className="text-sm text-white/80">Discover your personal completion percentage</p>
          </div>
        </div>

        {/* Start button */}
        <button
          onClick={onStart}
          className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-white font-bold text-base tracking-wide shadow-lg shadow-red-900/40 active:scale-95 transition-transform flex items-center justify-center gap-2 border border-red-500/30"
        >
          START MY JOURNEY
          <ChevronRight size={20} />
        </button>

        {/* Skip */}
        <button
          onClick={onSkip}
          className="mt-4 text-sm text-white/40 hover:text-white/60 transition-colors py-2"
        >
          Skip introduction
        </button>
      </div>
    </div>
  );
}

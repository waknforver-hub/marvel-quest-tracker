import { useEffect, useState } from 'react';

interface ProgressRingProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  sublabel?: string;
  animated?: boolean;
}

export function ProgressRing({
  percentage,
  size = 200,
  strokeWidth = 8,
  color = 'currentColor',
  trackColor = 'rgba(255,255,255,0.1)',
  label,
  sublabel,
  animated = true,
}: ProgressRingProps) {
  const [displayPercentage, setDisplayPercentage] = useState(animated ? 0 : percentage);
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (displayPercentage / 100) * circumference;

  useEffect(() => {
    if (!animated) {
      setDisplayPercentage(percentage);
      return;
    }
    const timer = setTimeout(() => setDisplayPercentage(percentage), 100);
    return () => clearTimeout(timer);
  }, [percentage, animated]);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={trackColor}
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1.2s ease-out' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold tabular-nums" style={{ color }}>
          {displayPercentage}%
        </span>
        {label && <span className="text-xs text-white/60 mt-1 uppercase tracking-wider">{label}</span>}
        {sublabel && <span className="text-[10px] text-white/40 mt-0.5">{sublabel}</span>}
      </div>
    </div>
  );
}

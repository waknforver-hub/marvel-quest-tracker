import { useState } from 'react';
import {
  X,
  User,
  Heart,
  Film,
  Edit2,
  Share2,
  Trash2,
  Check,
  AlertTriangle,
} from 'lucide-react';
import type { ProgressState } from '../types';
import { getReleasedTitles, getMcuTitles } from '../data/catalogue';
import { DOOMSDAY_PLAN } from '../data/doomsdayPlan';
import {
  countWatched,
  calcPercentage,
  getWatchedMinutes,
  formatHours,
  getFanRank,
} from '../utils/calculations';
import { MQLogo } from './Logo';
import { ProgressRing } from './ProgressRing';

interface ProfilePageProps {
  state: ProgressState;
  onSetProfile: (profile: Partial<ProgressState['profile']>) => void;
  onResetProgress: () => void;
  onClose: () => void;
}

const AVATAR_OPTIONS = ['hero', 'shield', 'star', 'mask'];

export function ProfilePage({ state, onSetProfile, onResetProgress, onClose }: ProfilePageProps) {
  const [editing, setEditing] = useState(false);
  const [showShareCard, setShowShareCard] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [nickname, setNickname] = useState(state.profile.nickname);
  const [favoriteCharacter, setFavoriteCharacter] = useState(state.profile.favoriteCharacter);
  const [favoriteMovie, setFavoriteMovie] = useState(state.profile.favoriteMovie);

  const releasedTitles = getReleasedTitles();
  const universeWatched = countWatched(state.watched, releasedTitles);
  const universePercent = calcPercentage(universeWatched, releasedTitles.length);
  const watchedMinutes = getWatchedMinutes(state.watched, releasedTitles);

  const mcuTitles = getMcuTitles();
  const mcuWatched = countWatched(state.watched, mcuTitles);
  const mcuPercent = calcPercentage(mcuWatched, mcuTitles.length);

  const doomsdayTitleIds = DOOMSDAY_PLAN.map((e) => e.titleId);
  const doomsdayTitles = doomsdayTitleIds
    .map((id) => releasedTitles.find((t) => t.id === id) || null)
    .filter((t): t is NonNullable<typeof t> => t !== null);
  const doomsdayWatched = countWatched(state.watched, doomsdayTitles);
  const doomsdayPercent = calcPercentage(doomsdayWatched, doomsdayTitles.length);

  const fanRank = getFanRank(universePercent, doomsdayPercent);

  const handleSave = () => {
    onSetProfile({ nickname, favoriteCharacter, favoriteMovie });
    setEditing(false);
  };

  const handleReset = () => {
    onResetProgress();
    setShowResetConfirm(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0e17] overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-[#0a0e17]/95 backdrop-blur-md border-b border-white/10 z-10">
        <div className="flex items-center justify-between px-4 h-14">
          <h2 className="text-sm font-bold tracking-wider text-white uppercase">Profile</h2>
          <button onClick={onClose} className="text-white/40 hover:text-white/70">
            <X size={20} />
          </button>
        </div>
      </div>

      <div className="px-4 py-6 max-w-md mx-auto">
        {/* Profile header */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative mb-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-700 to-red-900 flex items-center justify-center border border-red-500/30 shadow-lg">
              <User size={36} className="text-white/80" />
            </div>
          </div>
          <h3 className="text-xl font-bold text-white">{state.profile.nickname}</h3>
          {state.profile.favoriteCharacter && (
            <p className="text-sm text-white/40 mt-1">
              Favourite character: <span className="text-amber-400">{state.profile.favoriteCharacter}</span>
            </p>
          )}
          {state.profile.favoriteMovie && (
            <p className="text-sm text-white/40">
              Favourite movie: <span className="text-amber-400">{state.profile.favoriteMovie}</span>
            </p>
          )}
        </div>

        {/* Stats summary */}
        <div className="flex flex-col items-center mb-6">
          <ProgressRing percentage={universePercent} size={140} strokeWidth={8} color="#dc2626" label="Universe Completion" />
        </div>

        <div className="grid grid-cols-2 gap-2.5 mb-6">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Universe Watched</div>
            <div className="text-lg font-bold text-white">{universeWatched}/{releasedTitles.length}</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-white/40 uppercase tracking-wider">MCU Completion</div>
            <div className="text-lg font-bold text-white">{mcuPercent}%</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Doomsday Prep</div>
            <div className="text-lg font-bold text-white">{doomsdayPercent}%</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Watch Time</div>
            <div className="text-lg font-bold text-white">{formatHours(watchedMinutes)}</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-white/40 uppercase tracking-wider">Fan Rank</div>
            <div className="text-sm font-bold text-amber-400 leading-tight pt-1">{fanRank}</div>
          </div>
        </div>

        {/* Edit button */}
        {!editing ? (
          <button
            onClick={() => setEditing(true)}
            className="w-full py-3 rounded-xl bg-white/5 border border-white/10 text-sm font-medium text-white/80 flex items-center justify-center gap-2 mb-4 hover:bg-white/10 transition-all"
          >
            <Edit2 size={16} />
            Edit Profile
          </button>
        ) : (
          <div className="bg-white/5 rounded-xl p-4 border border-white/10 mb-4 space-y-3">
            <div>
              <label className="text-[10px] text-white/40 uppercase tracking-wider block mb-1">Nickname</label>
              <input
                type="text"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="Your nickname"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-red-500/50"
              />
            </div>
            <div>
              <label className="text-[10px] text-white/40 uppercase tracking-wider block mb-1">Favourite Character</label>
              <input
                type="text"
                value={favoriteCharacter}
                onChange={(e) => setFavoriteCharacter(e.target.value)}
                placeholder="e.g. Iron Man, Thor..."
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-red-500/50"
              />
            </div>
            <div>
              <label className="text-[10px] text-white/40 uppercase tracking-wider block mb-1">Favourite Movie</label>
              <input
                type="text"
                value={favoriteMovie}
                onChange={(e) => setFavoriteMovie(e.target.value)}
                placeholder="e.g. Avengers: Endgame..."
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-red-500/50"
              />
            </div>
            <div>
              <label className="text-[10px] text-white/40 uppercase tracking-wider block mb-2">Avatar Icon</label>
              <div className="flex gap-2">
                {AVATAR_OPTIONS.map((avatar) => (
                  <button
                    key={avatar}
                    onClick={() => onSetProfile({ avatar })}
                    className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center transition-all ${
                      state.profile.avatar === avatar
                        ? 'border-red-500 bg-red-900/30'
                        : 'border-white/10 bg-white/5'
                    }`}
                  >
                    {avatar === 'hero' && <User size={18} className="text-white/70" />}
                    {avatar === 'shield' && <Heart size={18} className="text-white/70" />}
                    {avatar === 'star' && <Film size={18} className="text-white/70" />}
                    {avatar === 'mask' && <User size={18} className="text-white/70" />}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={handleSave}
              className="w-full py-2.5 rounded-lg bg-red-700 text-white text-sm font-bold flex items-center justify-center gap-2"
            >
              <Check size={16} />
              Save
            </button>
          </div>
        )}

        {/* Share card button */}
        <button
          onClick={() => setShowShareCard(true)}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-white font-bold text-sm flex items-center justify-center gap-2 mb-4 border border-red-500/30 shadow-lg"
        >
          <Share2 size={16} />
          Share My Status
        </button>

        {/* Reset progress */}
        {!showResetConfirm ? (
          <button
            onClick={() => setShowResetConfirm(true)}
            className="w-full py-3 rounded-xl bg-white/5 border border-white/10 text-sm font-medium text-white/50 flex items-center justify-center gap-2 hover:bg-red-950/30 hover:text-red-400 transition-all"
          >
            <Trash2 size={16} />
            Reset Progress
          </button>
        ) : (
          <div className="bg-red-950/30 rounded-xl p-4 border border-red-900/30">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle size={18} className="text-red-400" />
              <span className="text-sm font-bold text-white">Reset all progress?</span>
            </div>
            <p className="text-xs text-white/50 mb-4">
              This will clear all watched titles, favourites, and history. This cannot be undone.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2.5 rounded-lg bg-white/5 text-sm text-white/60 border border-white/10"
              >
                Cancel
              </button>
              <button
                onClick={handleReset}
                className="flex-1 py-2.5 rounded-lg bg-red-700 text-sm font-bold text-white"
              >
                Reset Everything
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Share card modal */}
      {showShareCard && (
        <ShareCard
          state={state}
          universePercent={universePercent}
          mcuPercent={mcuPercent}
          doomsdayPercent={doomsdayPercent}
          watchedMinutes={watchedMinutes}
          fanRank={fanRank}
          onClose={() => setShowShareCard(false)}
        />
      )}
    </div>
  );
}

interface ShareCardProps {
  state: ProgressState;
  universePercent: number;
  mcuPercent: number;
  doomsdayPercent: number;
  watchedMinutes: number;
  fanRank: string;
  onClose: () => void;
}

function ShareCard({ state, universePercent, mcuPercent, doomsdayPercent, watchedMinutes, fanRank, onClose }: ShareCardProps) {
  const handleShare = async () => {
    const text = `MARVEL QUEST\n\n${state.profile.nickname}\n\nUniverse Completion: ${universePercent}%\nMCU Completion: ${mcuPercent}%\nDoomsday Preparation: ${doomsdayPercent}%\nWatch Time: ${formatHours(watchedMinutes)}\nStatus: ${fanRank.toUpperCase()}\n\nTrack your Marvel journey with Marvel Quest!`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Marvel Quest — My Status',
          text,
        });
      } catch {
        // user cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        // ignore
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
        {/* Cinematic share card */}
        <div
          className="rounded-2xl overflow-hidden border border-red-900/30 shadow-2xl"
          style={{
            background: 'linear-gradient(135deg, #0c0a08 0%, #1a1210 50%, #0c0a08 100%)',
          }}
        >
          <div className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <MQLogo size={32} />
                <div className="flex flex-col leading-none">
                  <span className="text-xs font-black tracking-widest text-white">MARVEL</span>
                  <span className="text-xs font-black tracking-widest text-amber-400">QUEST</span>
                </div>
              </div>
              <span className="text-[9px] text-red-400/40 uppercase tracking-widest">Mission Status</span>
            </div>

            {/* User name */}
            <h3 className="text-2xl font-black text-white text-center mb-6">{state.profile.nickname}</h3>

            {/* Stats */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-xs text-white/50 uppercase tracking-wider">Universe Completion</span>
                <span className="text-lg font-bold text-red-400 tabular-nums">{universePercent}%</span>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-xs text-white/50 uppercase tracking-wider">MCU Completion</span>
                <span className="text-lg font-bold text-white tabular-nums">{mcuPercent}%</span>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-xs text-white/50 uppercase tracking-wider">Doomsday Prep</span>
                <span className="text-lg font-bold text-red-400 tabular-nums">{doomsdayPercent}%</span>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-xs text-white/50 uppercase tracking-wider">Watch Time</span>
                <span className="text-lg font-bold text-amber-400">{formatHours(watchedMinutes)}</span>
              </div>
            </div>

            {/* Fan rank */}
            <div className="bg-red-950/30 rounded-xl p-4 border border-red-900/20 text-center">
              <div className="text-[10px] text-red-400/50 uppercase tracking-widest mb-1">Status</div>
              <div className="text-lg font-bold text-white uppercase tracking-wide">{fanRank}</div>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-black/40 px-6 py-3 border-t border-white/5">
            <p className="text-center text-[10px] text-white/30 tracking-wider">
              MARVEL QUEST · Track your journey
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2 mt-4">
          <button
            onClick={handleShare}
            className="flex-1 py-3 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-white font-bold text-sm flex items-center justify-center gap-2 border border-red-500/30"
          >
            <Share2 size={16} />
            Share
          </button>
          <button
            onClick={onClose}
            className="px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white/60 text-sm"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

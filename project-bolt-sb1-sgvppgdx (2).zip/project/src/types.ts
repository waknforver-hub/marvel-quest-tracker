export type ContentType = 'movie' | 'series' | 'animation' | 'anime' | 'special' | 'short';
export type Saga = 'Infinity Saga' | 'Multiverse Saga';
export type Phase = 1 | 2 | 3 | 4 | 5 | 6;
export type ReleaseStatus = 'released' | 'upcoming';

export type Universe =
  | 'MCU'
  | 'X-MEN'
  | 'SPIDER-MAN'
  | 'SONY MARVEL'
  | 'FANTASTIC FOUR'
  | 'LEGACY MARVEL'
  | 'MARVEL ANIMATION'
  | 'MARVEL ANIME'
  | 'OTHER MARVEL';

export interface McuTitle {
  id: string;
  title: string;
  year: number;
  type: ContentType;
  universe?: Universe;
  phase?: Phase;
  saga?: Saga;
  runtimeMinutes: number;
  episodes?: number;
  seasons?: number;
  rating: number | null;
  ratingSource: string;
  synopsis: string;
  whereToWatch: string[];
  releaseStatus: ReleaseStatus;
  releaseDate?: string;
  chronologicalOrder?: number;
  releaseOrder: number;
  category?: string;
}

export type DoomsdayCategory = 'core' | 'important' | 'optional' | 'extras';

export interface DoomsdayEntry {
  titleId: string;
  category: DoomsdayCategory;
  reason: string;
  plan: 'quick' | 'full' | 'both';
}

export interface UserProfile {
  nickname: string;
  avatar: string;
  favoriteCharacter: string;
  favoriteMovie: string;
}

export interface ProgressState {
  watched: Record<string, boolean>;
  inProgress: string[];
  favorites: string[];
  recentlyWatched: string[];
  filters: {
    type: 'ALL' | ContentType;
    universe: 'ALL' | Universe;
    phase: 'ALL' | Phase;
    saga: 'ALL' | Saga;
    watched: 'ALL' | 'watched' | 'unwatched' | 'in_progress';
  };
  watchOrder: 'release' | 'chronological';
  profile: UserProfile;
  hasSeenIntro: boolean;
  doomsdayPlan: 'quick' | 'full';
}

export type TabName = 'universe' | 'doomsday' | 'status';

export const UNIVERSE_LABELS: Record<Universe, string> = {
  MCU: 'MCU',
  'X-MEN': 'X-Men',
  'SPIDER-MAN': 'Spider-Man',
  'SONY MARVEL': 'Sony Marvel',
  'FANTASTIC FOUR': 'Fantastic Four',
  'LEGACY MARVEL': 'Legacy Marvel',
  'MARVEL ANIMATION': 'Marvel Animation',
  'MARVEL ANIME': 'Marvel Anime',
  'OTHER MARVEL': 'Other Marvel',
};

import { useState, useEffect } from 'react';
import type { TabName } from './types';
import { useProgress } from './hooks/useProgress';
import { IntroScreen } from './components/IntroScreen';
import { BottomNav } from './components/BottomNav';
import { UniverseTab } from './components/UniverseTab';
import { DoomsdayTab } from './components/DoomsdayTab';
import { StatusTab } from './components/StatusTab';
import { ProfilePage } from './components/ProfilePage';
import { App as CapacitorApp } from '@capacitor/app';

export default function App() {
  const {
    state,
    toggleWatched,
    toggleInProgress,
    toggleFavorite,
    setFilters,
    resetFilters,
    setWatchOrder,
    setProfile,
    setHasSeenIntro,
    setDoomsdayPlan,
    resetProgress,
  } = useProgress();

  const [activeTab, setActiveTab] = useState<TabName>('universe');
  const [showProfile, setShowProfile] = useState(false);

  useEffect(() => {
    let backHandler: { remove: () => void } | undefined;
    const setupListener = async () => {
      try {
        backHandler = await CapacitorApp.addListener('backButton', () => {
          if (showProfile) {
            setShowProfile(false);
          } else if (activeTab !== 'universe') {
            setActiveTab('universe');
          } else {
            CapacitorApp.exitApp();
          }
        });
      } catch {
        // Not running in Capacitor (web browser) — no-op
      }
    };
    setupListener();
    return () => {
      backHandler?.remove();
    };
  }, [showProfile, activeTab]);

  if (!state.hasSeenIntro) {
    return (
      <IntroScreen
        onStart={() => {
          setHasSeenIntro(true);
          setActiveTab('universe');
        }}
        onSkip={() => setHasSeenIntro(true)}
      />
    );
  }

  const doomsdayActive = activeTab === 'doomsday';

  return (
    <div className={doomsdayActive ? 'bg-[#0a0808]' : 'bg-[#0a0e17]'}>
      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onProfileClick={() => setShowProfile(true)}
        doomsdayActive={doomsdayActive}
      />

      <div className="min-h-screen">
        {activeTab === 'universe' && (
          <UniverseTab
            state={state}
            onToggleWatched={toggleWatched}
            onToggleInProgress={toggleInProgress}
            onToggleFavorite={toggleFavorite}
            onSetFilters={setFilters}
            onResetFilters={resetFilters}
            onSetWatchOrder={setWatchOrder}
          />
        )}
        {activeTab === 'doomsday' && (
          <DoomsdayTab
            state={state}
            onToggleWatched={toggleWatched}
            onSetDoomsdayPlan={setDoomsdayPlan}
          />
        )}
        {activeTab === 'status' && <StatusTab state={state} />}
      </div>

      {showProfile && (
        <ProfilePage
          state={state}
          onSetProfile={setProfile}
          onResetProgress={resetProgress}
          onClose={() => setShowProfile(false)}
        />
      )}
    </div>
  );
}

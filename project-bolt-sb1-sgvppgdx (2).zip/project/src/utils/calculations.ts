import type { ContentType, McuTitle, Phase, Saga, Universe } from '../types';
import { MCU_CATALOGUE, getReleasedTitles, getTitlesByUniverse, getMcuTitles } from '../data/catalogue';
import { DOOMSDAY_PLAN } from '../data/doomsdayPlan';

export function formatRuntime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export function formatHours(minutes: number): string {
  const h = (minutes / 60).toFixed(1);
  return `${h}h`;
}

export function countWatched(watched: Record<string, boolean>, titles: McuTitle[]): number {
  return titles.filter((t) => watched[t.id]).length;
}

export function calcPercentage(watchedCount: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((watchedCount / total) * 100);
}

export function getWatchedMinutes(watched: Record<string, boolean>, titles: McuTitle[]): number {
  return titles.filter((t) => watched[t.id]).reduce((sum, t) => sum + t.runtimeMinutes, 0);
}

export function getRemainingTitles(watched: Record<string, boolean>, titles: McuTitle[]): McuTitle[] {
  return titles.filter((t) => !watched[t.id]);
}

export interface FilterOptions {
  type: 'ALL' | ContentType;
  universe: 'ALL' | Universe;
  phase: 'ALL' | Phase;
  saga: 'ALL' | Saga;
  watched: 'ALL' | 'watched' | 'unwatched' | 'in_progress';
}

export function filterTitles(
  titles: McuTitle[],
  filters: FilterOptions,
  watched: Record<string, boolean>,
  inProgress: string[] = []
): McuTitle[] {
  return titles.filter((t) => {
    if (filters.type !== 'ALL' && t.type !== filters.type) return false;
    if (filters.universe !== 'ALL' && t.universe !== filters.universe) return false;
    if (filters.phase !== 'ALL' && t.phase !== filters.phase) return false;
    if (filters.saga !== 'ALL' && t.saga !== filters.saga) return false;
    if (filters.watched === 'watched' && !watched[t.id]) return false;
    if (filters.watched === 'unwatched' && watched[t.id]) return false;
    if (filters.watched === 'in_progress' && !inProgress.includes(t.id)) return false;
    return true;
  });
}

export function searchTitles(titles: McuTitle[], query: string): McuTitle[] {
  if (!query.trim()) return titles;
  const q = query.toLowerCase();
  return titles.filter(
    (t) =>
      t.title.toLowerCase().includes(q) ||
      String(t.year).includes(q) ||
      t.synopsis.toLowerCase().includes(q) ||
      (t.universe || '').toLowerCase().includes(q) ||
      (t.category || '').toLowerCase().includes(q)
  );
}

export function sortTitles(titles: McuTitle[], order: 'release' | 'chronological'): McuTitle[] {
  return [...titles].sort((a, b) =>
    order === 'release'
      ? a.releaseOrder - b.releaseOrder
      : (a.chronologicalOrder || a.releaseOrder) - (b.chronologicalOrder || b.releaseOrder)
  );
}

export function getTitlesByType(type: ContentType, released = true): McuTitle[] {
  const base = released ? getReleasedTitles() : MCU_CATALOGUE;
  return base.filter((t) => t.type === type);
}

export function getTitlesByPhase(phase: Phase, released = true): McuTitle[] {
  const base = released ? getReleasedTitles() : MCU_CATALOGUE;
  return base.filter((t) => t.phase === phase);
}

export function getTitlesBySaga(saga: Saga, released = true): McuTitle[] {
  const base = released ? getReleasedTitles() : MCU_CATALOGUE;
  return base.filter((t) => t.saga === saga);
}

export function getDoomsdayTitles(category?: string): McuTitle[] {
  const ids = DOOMSDAY_PLAN.filter((e) => !category || e.category === category).map((e) => e.titleId);
  return ids
    .map((id) => MCU_CATALOGUE.find((t) => t.id === id))
    .filter((t): t is McuTitle => t !== undefined);
}

export function getDoomsdayEntry(titleId: string) {
  return DOOMSDAY_PLAN.find((e) => e.titleId === titleId);
}

export function getDoomsdayPlanTitles(plan: 'quick' | 'full'): McuTitle[] {
  const ids = DOOMSDAY_PLAN.filter((e) => e.plan === plan || e.plan === 'both').map((e) => e.titleId);
  return ids
    .map((id) => MCU_CATALOGUE.find((t) => t.id === id))
    .filter((t): t is McuTitle => t !== undefined);
}

export type FanRank =
  | 'Beginning the Journey'
  | 'Hero in Training'
  | 'Avenger in Progress'
  | 'Multiverse Explorer'
  | 'Doomsday Ready';

export function getFanRank(universePercent: number, doomsdayPercent: number): FanRank {
  const combined = (universePercent + doomsdayPercent) / 2;
  if (combined >= 85) return 'Doomsday Ready';
  if (combined >= 60) return 'Multiverse Explorer';
  if (combined >= 35) return 'Avenger in Progress';
  if (combined >= 10) return 'Hero in Training';
  return 'Beginning the Journey';
}

export function getCountdown(targetDate: string): {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  expired: boolean;
} {
  const target = new Date(targetDate).getTime();
  const now = Date.now();
  const diff = target - now;
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);
  return { days, hours, minutes, seconds, expired: false };
}

export { getTitlesByUniverse, getMcuTitles };

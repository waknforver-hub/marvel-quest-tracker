import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.marvelquest.app',
  appName: 'Marvel Quest',
  webDir: 'dist',
  android: {
    backgroundColor: '#0a0e17',
  },
};

export default config;
